//Gfx converted using Mollusk's PAGfx Converter

//This file contains all the .c, for easier inclusion in a project

#ifdef __cplusplus
extern "C" {
#endif

#include "all_gfx.h"


// Background files : 
#include "sysfont.c"
#include "font8px.c"
#include "tinyfont.c"

// Palette files : 

// Background Pointers :


#ifdef __cplusplus
}
#endif

