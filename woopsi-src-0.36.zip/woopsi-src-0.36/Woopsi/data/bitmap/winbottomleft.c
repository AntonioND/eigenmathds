// 16bit Bitmap created using PAGfx

const unsigned short winbottomleft_Bitmap[25] __attribute__ ((aligned (4))) = {
32768, 50769, 46477, 44395, 32768, 32768, 50769, 46477, 44395, 50769, 33825, 50769, 46477, 46477, 46477, 33825, 
44395, 44395, 44395, 44395, 32768, 32768, 32768, 32768, 32768
};

