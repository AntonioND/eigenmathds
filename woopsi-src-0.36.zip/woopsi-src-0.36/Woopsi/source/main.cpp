// Includes
#include "demo.h"

int main(int argc, char* argv[]) {

	// Create the demo application
	Demo demo;
	return demo.main(argc, argv);
}
