Bonus Code
----------

  This folder contains extra C++ classes that are not part of the main Woopsi
  library code.  To use them, drop them into your source folder and include
  them in your project.
  
Helpers
-------

  Classes in this folder abstract some of the complexities of Woopsi away to
  make applications easier to write.
  
Collections
-----------

  Woopsi intentionally makes no use of the STL collection classes (vector, etc),
  instead making use of its own DynamicArray class.  This is done to reduce the
  size of Woopsi ROMs.  The collections in this folder are a linked list and a
  hashmap.  Both have associated iterator classes.
  
Gadgets
-------

  Extra gadgets that aren't officially part of Woopsi, or have external
  dependencies that will bulk up the size of the ROM if they were included by
  default.