// Includes
#include "helloworld.h"

int main(int argc, char* argv[]) {

	// Create the Hello World application
	HelloWorld app;
	return app.main(argc, argv);
}
