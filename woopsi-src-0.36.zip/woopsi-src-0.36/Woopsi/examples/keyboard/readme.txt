Keyboard
--------

  This example shows how to create an instance of the WoopsiKeyboard class, use
  it to read textual user input, and output that text to the screen.

  
Building the Example
--------------------

  To build this example, open a shell, navigate to this directory, and type
  "make".  Note that this will also compile the Woopsi source; this will be
  necessary until Woopsi ships as a library.