// Includes
#include "keytest.h"

int main(int argc, char* argv[]) {

	// Create the application
	KeyTest app;
	return app.main(argc, argv);
}
