// Includes
#include "calendartest.h"

int main(int argc, char* argv[]) {

	// Create the test application
	CalendarTest app;
	return app.main(argc, argv);
}
