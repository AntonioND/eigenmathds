// Includes
#include "wpaint.h"

int main(int argc, char* argv[]) {

	// Create the WPaint application
	WPaint app;
	return app.main(argc, argv);
}
