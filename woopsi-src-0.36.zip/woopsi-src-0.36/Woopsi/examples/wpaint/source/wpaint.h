#ifndef _WPAINT_H_
#define _WPAINT_H_

#include "woopsi.h"

using namespace WoopsiUI;

class WPaint : public Woopsi {
public:
	void startup();
	void shutdown();
};

#endif
