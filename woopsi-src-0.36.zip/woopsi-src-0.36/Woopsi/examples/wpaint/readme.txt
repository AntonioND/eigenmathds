WPaint
------

  This is a very quick and dirty example of how to use the SuperBitmap's drawing
  tools to create a paint package.

Building the Example
--------------------

  To build this example, open a shell, navigate to this directory, and type
  "make".  Note that this will also compile the Woopsi source; this will be
  necessary until Woopsi ships as a library.