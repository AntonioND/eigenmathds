Timer
-----

  This example shows how to create an instance of the WoopsiTimer class and use
  it to control VBL/time-based effects.
  
  In the example, a textbox shows individual lower-case letters sequentially
  from a to z.  Every 10 frames, the text box updates to show the next letter in
  the sequence.

  
Building the Example
--------------------

  To build this example, open a shell, navigate to this directory, and type
  "make".  Note that this will also compile the Woopsi source; this will be
  necessary until Woopsi ships as a library.