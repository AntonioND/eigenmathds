// Includes
#include "timertest.h"

int main(int argc, char* argv[]) {

	// Create the application
	TimerTest app;
	return app.main(argc, argv);
}
