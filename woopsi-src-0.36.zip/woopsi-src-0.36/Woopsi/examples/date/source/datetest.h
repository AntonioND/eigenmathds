#ifndef _CALENDAR_TEST_H_
#define _CALENDAR_TEST_H_

#include "woopsi.h"

using namespace WoopsiUI;

class DateTest : public Woopsi {
public:
	void startup();
	void shutdown();
};

#endif
