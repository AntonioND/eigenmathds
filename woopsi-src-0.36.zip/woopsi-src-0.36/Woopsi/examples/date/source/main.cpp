// Includes
#include "datetest.h"

int main(int argc, char* argv[]) {

	// Create the test application
	DateTest app;
	return app.main(argc, argv);
}
