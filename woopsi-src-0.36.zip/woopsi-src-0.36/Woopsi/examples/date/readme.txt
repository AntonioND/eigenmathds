Date Test
---------

  This example shows how the Date class should be used.
  
  The Date class really only exists to provide date manipulation functionality
  for the Calendar class, so this example is really just a manual unit test.
  

Building the Example
--------------------

  To build this example, open a shell, navigate to this directory, and type
  "make".  Note that this will also compile the Woopsi source; this will be
  necessary until Woopsi ships as a library.