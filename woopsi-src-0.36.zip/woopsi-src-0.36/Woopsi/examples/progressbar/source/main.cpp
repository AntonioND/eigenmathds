// Includes
#include "progressbartest.h"

int main(int argc, char* argv[]) {

	// Create the test application
	ProgressBarTest app;
	return app.main(argc, argv);
}
