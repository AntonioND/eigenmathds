// Includes
#include "woopsiheaders.h"

using namespace WoopsiUI;

int main(int argc, char* argv[]) {

	// Create Woopsi instance
	woopsiApplication = new Woopsi();

	// Start up Woopsi application
	woopsiApplication->startup();
	
	// Create screen
	AmigaScreen* screen = new AmigaScreen("Hello World Screen", Gadget::GADGET_DRAGGABLE, AmigaScreen::AMIGA_SCREEN_SHOW_DEPTH | AmigaScreen::AMIGA_SCREEN_SHOW_FLIP);
	woopsiApplication->addGadget(screen);

	// Add window
	AmigaWindow* window = new AmigaWindow(0, 13, 256, 179, "Hello World Window", Gadget::GADGET_DRAGGABLE, AmigaWindow::AMIGA_WINDOW_SHOW_CLOSE | AmigaWindow::AMIGA_WINDOW_SHOW_DEPTH);
	screen->addGadget(window);

	// Get available area within window
	Gadget::Rect rect;
	window->getClientRect(rect);
	
	// Add textbox
	TextBox* textbox = new TextBox(rect.x, rect.y, rect.width, rect.height, "Hello World!");
	window->addGadget(textbox);
	
	AmigaWindow* window2 = new AmigaWindow(0, 13, 256, 179, "Window2", Gadget::GADGET_DRAGGABLE, AmigaWindow::AMIGA_WINDOW_SHOW_CLOSE | AmigaWindow::AMIGA_WINDOW_SHOW_DEPTH);
	screen->addGadget(window2);
	
	TextBox* textbox2 = new TextBox(rect.x+10, rect.y+10, rect.width-20, rect.height-20, "Hola mundo!");
	window2->addGadget(textbox2);

	// Ensure Woopsi can draw itself
	woopsiApplication->enableDrawing();
	
	// Draw GUI
	woopsiApplication->draw();
	
	// Run Woopsi
	woopsiApplication->goModal();
	
	// Finish up
	woopsiApplication->shutdown();
	
	return 0;
}
