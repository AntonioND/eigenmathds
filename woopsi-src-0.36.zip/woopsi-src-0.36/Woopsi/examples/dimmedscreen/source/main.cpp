// Includes
#include "dimmedscreentest.h"

int main(int argc, char* argv[]) {

	// Create the test application
	DimmedScreenTest app;
	return app.main(argc, argv);
}
