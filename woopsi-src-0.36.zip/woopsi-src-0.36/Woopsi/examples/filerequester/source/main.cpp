// Includes
#include "filereqdemo.h"

using namespace WoopsiUI;

int main(int argc, char* argv[]) {

	// Create the file requester demo application
	FileReqDemo app;
	return app.main(argc, argv);
}
